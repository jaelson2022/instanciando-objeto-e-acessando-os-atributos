package ClínicaVeterinária;

public class Cachorro {

    String nome;
    String raca;
    String sexo;
    int idade;
}
